<?php     
    $to_email = 'mandharsh38@icloud.com';
    $subject = 'Website Form';
    $name= 'Name: '.$_GET['name']."\r\n";
    $state= 'State: '.$_GET['state']."\r\n";
    $mobile= 'Mobile Number: '.$_GET['mobile']."\r\n";
    $email= 'Email: '.$_GET['email']."\r\n";
    $messg= 'Message: '.$_GET['body'];
    $headers = 'From: contact@votizenhealthcare.com';
    $message = $name.$state.$mobile.$email.$messg;
    mail($to_email,$subject,$message,$headers);
    echo "<script>
             alert('message sent succesfully'); 
             window.history.go(-1);
     </script>";
?>